<?php
    
    $host = "127.0.0.1";
    $user = "root";
    $clave = "Admin1248";
    $bd  = "db_proy";

$conectar = mysqli_connect($host,$user,$clave,$bd);


?>