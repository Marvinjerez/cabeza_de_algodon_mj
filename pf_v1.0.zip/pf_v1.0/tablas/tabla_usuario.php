<?php 

$host = "localhost";
$user = "root";
$clave = "Admin1248";
$bd  = "db_proy";

$conectar = mysqli_connect($host,$user,$clave,$bd);


 ?>


<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="icon" href="../img/icon.png">
  <link rel="stylesheet" href="style_tablas.css">
  <title>Usuarios</title>
</head>
<body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

    <ul>
        <li><a class="active" href="../dashboard/dashboard.html">Dashboard</a></li>
    </ul>
    
<br>
     
	<table>
		<tr>
		<h1>Base De Datos Usuarios</h1>
			<td>ID</td>
			<td>Nombre del Usuario</td>
			<td>Contraseña de la cuenta</td>
			<td>Rol</td>	
		</tr>

		<?php 

		$sql="SELECT * from users";
		$result=mysqli_query($conectar,$sql);

		while($mostrar=mysqli_fetch_array($result)){
		 ?>

		<tr>
			<td><?php echo $mostrar['id_user'] ?></td>
			<td><?php echo $mostrar['usuario'] ?></td>
			<td><?php echo $mostrar['contraseña'] ?></td>
			<td><?php echo $mostrar['rol'] ?></td>
		</tr>
	<?php 
	}
	 ?>
	</table>

</body>
</html>