<?php

include('conex.php');

$user = $_POST['usuario'];
$pass = $_POST['contraseña'];

session_start();

$_SESSION['usuario']=$user;

$conex = mysqli_connect("localhost","root","Admin1248","db_proy");

$consulta1 = "SELECT * FROM users WHERE usuario='$user' AND contraseña='$pass' AND rol ='admin'";

$query = mysqli_query($conex, $consulta1);

$filas=mysqli_num_rows($query);


if($consulta1){

    header("location:../dashboard/dashboard.html");


    
}else{

  header("location:../index/index.html");

}
mysqli_free_result($query);
mysqli_close($rol);